/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mythread;

/**
 *
 * @author Hp
 */
public class MyThread extends Thread {
    @Override
    public void run(){
        System.out.println("Thread is running");
    }
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        MyThread t = new MyThread ();
      t.start();
    }
    
}
